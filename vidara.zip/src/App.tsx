import { useState, useEffect } from "react";
import { UserProfile, ActivityLog } from "./types";
import LandingPage from "./components/LandingPage";
import AuthPage from "./components/AuthPage";
import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import Learning from "./components/Learning";
import Execution from "./components/Execution";
import AIAssistance from "./components/AIAssistance";
import Community from "./components/Community";
import Monetization from "./components/Monetization";
import AdminPanel from "./components/AdminPanel";
import { Bell, Trophy, ShieldAlert, Sparkles } from "lucide-react";

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [viewState, setViewState] = useState<"landing" | "auth" | "workspace">("landing");
  const [activeTab, setActiveTab] = useState<string>("dashboard");
  const [notifications, setNotifications] = useState<Array<{ id: string; text: string; time: string; read: boolean }>>([
    { id: "n_1", text: "AI Coach completed evaluation of Aesthetify CSS helper. Level up!", time: "1h ago", read: false },
    { id: "n_2", text: "Marcus Chen replied to your thread in #founder-circles", time: "2h ago", read: false }
  ]);
  const [showNotificationDropdown, setShowNotificationDropdown] = useState(false);

  // Resume Session on Reload
  useEffect(() => {
    const cachedUser = localStorage.getItem("vidara_session_profile");
    if (cachedUser) {
      try {
        const parsed = JSON.parse(cachedUser);
        setUser(parsed);
        setViewState("workspace");
      } catch (e) {
        localStorage.removeItem("vidara_session_profile");
      }
    }
  }, []);

  const handleAuthSuccess = (newProfile: UserProfile) => {
    setUser(newProfile);
    localStorage.setItem("vidara_session_profile", JSON.stringify(newProfile));
    setViewState("workspace");
  };

  const handleUpdateUser = (updatedProfile: UserProfile) => {
    setUser(updatedProfile);
    localStorage.setItem("vidara_session_profile", JSON.stringify(updatedProfile));
  };

  const handleAddTaskHistory = (newHistoryLog: ActivityLog) => {
    if (!user) return;
    
    // Add custom notification for gamified experience
    const notificationText = `Earned +${newHistoryLog.xpEarned} XP: ${newHistoryLog.description}`;
    const newNotif = {
      id: "n_" + Math.random().toString(36).substr(2, 9),
      text: notificationText,
      time: "Just now",
      read: false
    };

    setNotifications([newNotif, ...notifications]);

    // Check achievement unlock trigger condition dynamically (e.g., reaching 1500 XP)
    let unlockedAchievements = [...user.achievements];
    if (user.xp + newHistoryLog.xpEarned >= 1500 && !user.achievements.some(a => a.id === "ach_gold_builder")) {
      unlockedAchievements.push({
        id: "ach_gold_builder",
        title: "Gold Rank Builder",
        description: "Passed 1,500 total action experience points. Mastered core validation checklists.",
        unlockedAt: new Date().toISOString(),
        icon: "Trophy",
        xpReward: 300
      });
      alert("🏆 ACHIEVEMENT UNLOCKED: 'Gold Rank Builder'! Claimed +300 XP bonus.");
    }

    handleUpdateUser({
      ...user,
      xp: user.xp + newHistoryLog.xpEarned,
      achievements: unlockedAchievements,
      activityHistory: [newHistoryLog, ...user.activityHistory]
    });
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("vidara_session_profile");
    setViewState("landing");
    setActiveTab("dashboard");
  };

  const handleMarkNotificationsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
    setShowNotificationDropdown(false);
  };

  // Determine if User holds Admin title / console access
  const isAdmin = user?.email === "satyajitr225@gmail.com" || user?.username === "hacker_alpha";

  return (
    <div className="min-h-screen bg-[#030206] text-slate-100 font-sans selection:bg-purple-500 overflow-x-hidden antialiased">
      
      {/* 1. Landing View */}
      {viewState === "landing" && (
        <LandingPage onJoin={() => setViewState("auth")} />
      )}

      {/* 2. Onboarding Auth View */}
      {viewState === "auth" && (
        <AuthPage 
          onAuthSuccess={handleAuthSuccess} 
          onBackToLanding={() => setViewState("landing")} 
        />
      )}

      {/* 3. Main Full-Stack Application Grid Layout */}
      {viewState === "workspace" && user && (
        <div className="flex h-screen overflow-hidden custom-gradient-bg">
          
          {/* Sidebar */}
          <Sidebar 
            user={user} 
            activeTab={activeTab} 
            setActiveTab={setActiveTab} 
            onLogout={handleLogout}
            isAdmin={isAdmin}
          />

          {/* Core Content Area */}
          <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
            
            {/* Top Workspace Header Controls */}
            <header className="h-16 border-b border-white/5 flex items-center justify-between px-8 bg-slate-950/20 backdrop-blur-md shrink-0 relative z-30">
              
              <div className="flex items-center space-x-2">
                <span className="text-xs text-slate-500 font-mono">Current room:</span>
                <span className="p-1 px-2.5 rounded bg-purple-500/10 border border-purple-500/15 text-[11px] text-purple-300 font-mono uppercase tracking-widest">{activeTab}</span>
              </div>

              {/* Notification bell and profile trigger */}
              <div className="flex items-center space-x-4">
                
                {/* Notification Dropdown Container */}
                <div className="relative">
                  <button 
                    onClick={() => setShowNotificationDropdown(!showNotificationDropdown)}
                    className="p-2 rounded-xl border border-white/5 hover:bg-white/5 text-slate-400 hover:text-white transition-all cursor-pointer relative"
                  >
                    <Bell className="w-4.5 h-4.5" />
                    {notifications.some(n => !n.read) && (
                      <span className="absolute top-1 right-1 w-2 h-2 bg-purple-500 rounded-full animate-ping" />
                    )}
                  </button>

                  {showNotificationDropdown && (
                    <div className="absolute right-0 mt-3 w-80 glass p-4 rounded-xl border border-white/10 shadow-2xl z-50 space-y-3.5 animate-fade-in text-left">
                      <div className="flex justify-between items-center pb-2 border-b border-white/5">
                        <span className="font-bold text-xs text-white uppercase tracking-wider">Builder Feed</span>
                        <button 
                          onClick={handleMarkNotificationsRead}
                          className="text-[10px] text-purple-400 hover:text-purple-300 font-semibold cursor-pointer"
                        >
                          Mark all read
                        </button>
                      </div>

                      <div className="space-y-2.5 max-h-[250px] overflow-y-auto">
                        {notifications.map((notif) => (
                          <div 
                            key={notif.id} 
                            className={`p-2.5 rounded-lg text-xs leading-normal transition-colors border ${
                              notif.read ? "bg-white/1 border-transparent text-slate-400" : "bg-purple-600/5 border-purple-500/20 text-slate-200 font-medium"
                            }`}
                          >
                            <p>{notif.text}</p>
                            <span className="text-[9px] text-slate-500 font-mono mt-1 block">{notif.time}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Profile Widget */}
                <div className="flex items-center space-x-2.5 border-l border-white/5 pl-4">
                  <img 
                    src={user.photoUrl} 
                    alt={user.name} 
                    className="w-7.5 h-7.5 rounded-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="hidden sm:block text-left">
                    <span className="block text-xs font-bold text-white leading-tight">{user.name}</span>
                    <span className="block text-[9px] text-emerald-400 font-mono leading-none tracking-wide mt-0.5">● Level {user.level}</span>
                  </div>
                </div>

              </div>

            </header>

            {/* Scrollable Container Body */}
            <main className="flex-1 overflow-y-auto p-8 scrollbar-hide relative z-10">
              
              {activeTab === "dashboard" && (
                <Dashboard 
                  user={user} 
                  onUpdateUser={handleUpdateUser} 
                  onAddTaskHistory={handleAddTaskHistory} 
                />
              )}

              {activeTab === "learning" && (
                <Learning 
                  user={user} 
                  onUpdateUser={handleUpdateUser} 
                  onAddTaskHistory={handleAddTaskHistory} 
                />
              )}

              {activeTab === "execution" && (
                <Execution 
                  user={user} 
                  onUpdateUser={handleUpdateUser} 
                  onAddTaskHistory={handleAddTaskHistory} 
                />
              )}

              {activeTab === "ai-assistant" && (
                <AIAssistance user={user} />
              )}

              {activeTab === "community" && (
                <Community user={user} />
              )}

              {activeTab === "monetization" && (
                <Monetization user={user} />
              )}

              {activeTab === "admin" && isAdmin && (
                <AdminPanel user={user} />
              )}

            </main>

          </div>

        </div>
      )}

    </div>
  );
}
