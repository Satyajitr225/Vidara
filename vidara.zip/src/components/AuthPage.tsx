import React, { useState } from "react";
import { UserProfile } from "../types";
import { Sparkles, Check, ArrowRight, ArrowLeft, Shield } from "lucide-react";

interface AuthPageProps {
  onAuthSuccess: (user: UserProfile) => void;
  onBackToLanding: () => void;
}

export default function AuthPage({ onAuthSuccess, onBackToLanding }: AuthPageProps) {
  const [step, setStep] = useState<"login" | "signup" | "interests" | "skill">("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  
  // Onboarding states
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [selectedLevel, setSelectedLevel] = useState<"Beginner" | "Intermediate" | "Hardcore Builder">("Intermediate");
  const [bio, setBio] = useState("");

  const interestsOptions = [
    "SaaS Building",
    "Solopreneurship",
    "Fullstack Coding",
    "UX/UI Product Design",
    "Growth Hacking",
    "AI Engineering",
    "No-Code Prototyping",
    "Copywriting",
    "Community Building"
  ];

  const handleToggleInterest = (interest: string) => {
    if (selectedInterests.includes(interest)) {
      setSelectedInterests(selectedInterests.filter((i) => i !== interest));
    } else {
      setSelectedInterests([...selectedInterests, interest]);
    }
  };

  const handleSignupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || !name || !username) {
      alert("Please fill in all the core fields.");
      return;
    }
    setStep("interests");
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      alert("Please provide credentials.");
      return;
    }
    // Standard fast dummy login that bootstraps complete mock data.
    const mockUser: UserProfile = {
      id: "usr_" + Math.random().toString(36).substr(2, 9),
      username: username || "hacker_alpha",
      name: name || "Creative Build Master",
      email: email,
      photoUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
      bio: "Shipping MVPs in public. Hyperfocused on SaaS architecture and community growth loops.",
      skills: ["React", "TypeScript", "TailwindCSS", "Node.js", "AI Integration"],
      interests: ["SaaS Building", "Fullstack Coding", "AI Engineering"],
      skillLevel: "Hardcore Builder",
      currentGoals: ["Launch Vidara on Product Hunt", "Reach 100 consecutive streak logs"],
      streak: 7,
      xp: 1250,
      level: 4,
      executionScore: 84,
      achievements: [
        {
          id: "ach_1",
          title: "Sovereign Inception",
          description: "Initiated workspace profile and committed to a real-world launch roadmap.",
          unlockedAt: new Date().toISOString(),
          icon: "Shield",
          xpReward: 100
        },
        {
          id: "ach_2",
          title: "Midnight Oil",
          description: "Logged focus sessions past midnight 3 days in a single week",
          unlockedAt: new Date().toISOString(),
          icon: "Moon",
          xpReward: 200
        }
      ],
      publicPortfolio: [
        {
          id: "port_1",
          title: "Aesthetify CSS Helper",
          description: "A gorgeous tailwind theme configuration engine launched to developers.",
          link: "https://aesthetify.vidara.io",
          createdAt: "2026-05-18T04:16:00Z",
          xpGained: 450,
          score: 9,
          likes: 24,
          comments: []
        }
      ],
      activityHistory: [
        {
          id: "act_1",
          type: "goal_created",
          description: "Set a 4-week execution goal for custom SaaS helper.",
          timestamp: "2026-05-19T10:30:00Z",
          xpEarned: 50
        }
      ],
      socialLinks: {
        twitter: "https://twitter.com/vidara_builder",
        github: "https://github.com/vidara-labs"
      }
    };
    onAuthSuccess(mockUser);
  };

  const handleFinishOnboarding = () => {
    const finalProfile: UserProfile = {
      id: "usr_" + Math.random().toString(36).substr(2, 9),
      username: username.toLowerCase().replace(/\s+/g, "_") || "builder_pro",
      name,
      email,
      photoUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
      bio: bio || `Passionate builder focused in ${selectedInterests.slice(0, 3).join(", ")}. Determined to build real MVPs instead of staying stuck in tutorials.`,
      skills: selectedInterests.slice(0, 4),
      interests: selectedInterests,
      skillLevel: selectedLevel,
      currentGoals: ["First MVP validation launch", "Create a structured 4-week AI Roadmap"],
      streak: 1,
      xp: 150, // Initial onboarding bonus
      level: 1,
      executionScore: 0,
      achievements: [
        {
          id: "ach_1",
          title: "First Steps",
          description: "Completed profile creation and selected personal execution focus track.",
          unlockedAt: new Date().toISOString(),
          icon: "Sparkles",
          xpReward: 150
        }
      ],
      publicPortfolio: [],
      activityHistory: [
        {
          id: "act_init",
          type: "task_completed",
          description: "Account registration and profile configuration",
          timestamp: new Date().toISOString(),
          xpEarned: 150
        }
      ],
      socialLinks: {}
    };
    onAuthSuccess(finalProfile);
  };

  return (
    <div className="min-h-screen text-slate-100 flex items-center justify-center custom-gradient-bg px-6 relative py-12">
      {/* Top Absolute Brand Backer */}
      <div className="absolute top-8 left-8 flex items-center space-x-2.5 cursor-pointer hover:opacity-80 transition-opacity" onClick={onBackToLanding}>
        <div className="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center font-display font-extrabold text-sm">V</div>
        <span className="font-display font-medium text-sm text-slate-300">Vidara HQ</span>
      </div>

      <div className="w-full max-w-md glass p-8 rounded-2xl border border-white/10 shadow-2xl relative">
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-600/10 blur-2xl -z-10 rounded-full" />

        {/* 1. Login Step */}
        {step === "login" && (
          <div>
            <div className="text-center mb-6">
              <h2 className="text-2xl font-display font-black text-white">Welcome Back</h2>
              <p className="text-xs text-slate-400 mt-1">Ready to resume your building sprint?</p>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] text-slate-400 font-mono uppercase tracking-widest mb-1">Email representation</label>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. you@engine.com" 
                  className="w-full px-4 py-3 bg-slate-900 border border-white/5 rounded-xl text-sm focus:border-purple-500/50 outline-none transition-all placeholder:text-slate-600"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 font-mono uppercase tracking-widest mb-1">Secret Key / Password</label>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••" 
                  className="w-full px-4 py-3 bg-slate-900 border border-white/5 rounded-xl text-sm focus:border-purple-500/50 outline-none transition-all placeholder:text-slate-600"
                  required
                />
              </div>

              <button 
                type="submit"
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm transition-all shadow-lg active:scale-95 flex items-center justify-center space-x-2 cursor-pointer mt-6"
              >
                <span>Access Workspace</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            <div className="mt-6 text-center text-xs text-slate-500">
              New here?{" "}
              <button onClick={() => setStep("signup")} className="text-purple-400 hover:text-purple-300 font-semibold cursor-pointer">
                Create Builder Account
              </button>
            </div>
          </div>
        )}

        {/* 2. Signup Step */}
        {step === "signup" && (
          <div>
            <div className="text-center mb-6">
              <h2 className="text-2xl font-display font-black text-white">Join The Council</h2>
              <p className="text-xs text-slate-400 mt-1">Let's create your unique public engineering workspace.</p>
            </div>

            <form onSubmit={handleSignupSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] text-slate-400 font-mono uppercase tracking-widest mb-1">Full Name</label>
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="your display name" 
                  className="w-full px-4 py-3 bg-slate-900 border border-white/5 rounded-xl text-sm focus:border-purple-500/50 outline-none transition-all placeholder:text-slate-600"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 font-mono uppercase tracking-widest mb-1">Username</label>
                <input 
                  type="text" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. solobuilder_01" 
                  className="w-full px-4 py-3 bg-slate-900 border border-white/5 rounded-xl text-sm focus:border-purple-500/50 outline-none transition-all placeholder:text-slate-600"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 font-mono uppercase tracking-widest mb-1">Developer Email</label>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com" 
                  className="w-full px-4 py-3 bg-slate-900 border border-white/5 rounded-xl text-sm focus:border-purple-500/50 outline-none transition-all placeholder:text-slate-600"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 font-mono uppercase tracking-widest mb-1">Password</label>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="minimum 8 characters" 
                  className="w-full px-4 py-3 bg-slate-900 border border-white/5 rounded-xl text-sm focus:border-purple-500/50 outline-none transition-all placeholder:text-slate-600"
                  required
                />
              </div>

              <button 
                type="submit"
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm transition-all shadow-lg active:scale-95 flex items-center justify-center space-x-2 cursor-pointer mt-6"
              >
                <span>Continue to Onboarding</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            <div className="mt-6 text-center text-xs text-slate-500">
              Already have an account?{" "}
              <button onClick={() => setStep("login")} className="text-purple-400 hover:text-purple-300 font-semibold cursor-pointer">
                Sign In
              </button>
            </div>
          </div>
        )}

        {/* 3. Onboarding: Interests Track */}
        {step === "interests" && (
          <div>
            <div className="text-center mb-6">
              <span className="text-[10px] font-mono text-purple-400 uppercase tracking-widest">Onboarding Section • 01</span>
              <h2 className="text-xl font-display font-extrabold text-white mt-1">Select Your Core Target Focuses</h2>
              <p className="text-xs text-slate-400 mt-1">What are you aiming to master or build this quarter?</p>
            </div>

            <div className="flex flex-wrap gap-2.5 my-6 max-h-[250px] overflow-y-auto pr-1">
              {interestsOptions.map((opt) => {
                const isSelected = selectedInterests.includes(opt);
                return (
                  <button
                    key={opt}
                    onClick={() => handleToggleInterest(opt)}
                    className={`px-4 py-2.5 rounded-xl text-xs font-semibold select-none transition-all flex items-center space-x-2 border cursor-pointer ${
                      isSelected 
                        ? "bg-purple-600/30 border-purple-500 text-purple-100 shadow-md shadow-purple-950/20" 
                        : "bg-slate-900/40 border-white/5 text-slate-400 hover:border-white/10 hover:bg-slate-900"
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5 text-purple-400" />}
                    <span>{opt}</span>
                  </button>
                );
              })}
            </div>

            <div className="flex justify-between items-center mt-8">
              <button 
                onClick={() => setStep("signup")}
                className="px-4 py-2.5 rounded-xl border border-white/5 hover:bg-white/5 text-xs font-semibold hover:text-white text-slate-400 transition-all flex items-center space-x-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>

              <button 
                onClick={() => {
                  if (selectedInterests.length === 0) {
                    alert("Please select at least one interest to customized your feed!");
                    return;
                  }
                  setStep("skill");
                }}
                className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-bold text-white transition-all flex items-center space-x-1.5 active:scale-95 cursor-pointer"
              >
                <span>Next Step</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* 4. Onboarding: Skill Selection & Bio */}
        {step === "skill" && (
          <div>
            <div className="text-center mb-6">
              <span className="text-[10px] font-mono text-purple-400 uppercase tracking-widest">Onboarding Section • 02</span>
              <h2 className="text-xl font-display font-extrabold text-white mt-1">Identify Your Current Rank</h2>
              <p className="text-xs text-slate-400 mt-1">Be honest. We adapt AI feedback to challenge your level.</p>
            </div>

            <div className="space-y-3.5 my-6">
              {[
                {
                  id: "Beginner",
                  title: "Aspirant Builder",
                  desc: "Tutorial bound. Wrote some code, but never launched a real project with real active users."
                },
                {
                  id: "Intermediate",
                  title: "Active Developer",
                  desc: "Comfortable shipping backend APIs. Looking to grow target frameworks and master monetization."
                },
                {
                  id: "Hardcore Builder",
                  title: "Hardcore Maker",
                  desc: "Independent operator. Multi-stack builder shipping in public regularly."
                }
              ].map((lvl) => {
                const isSelected = selectedLevel === lvl.id;
                return (
                  <div
                    key={lvl.id}
                    onClick={() => setSelectedLevel(lvl.id as any)}
                    className={`p-4 rounded-xl border text-left cursor-pointer transition-all ${
                      isSelected 
                        ? "bg-purple-500/10 border-purple-500" 
                        : "bg-slate-900/40 border-white/5 hover:border-white/10"
                    }`}
                  >
                    <div className="font-bold text-xs text-white uppercase tracking-wider">{lvl.title}</div>
                    <div className="text-[11px] text-slate-400 mt-1 font-light leading-relaxed">{lvl.desc}</div>
                  </div>
                );
              })}
            </div>

            <div className="space-y-1 mb-6">
              <label className="block text-[10px] text-slate-400 font-mono uppercase tracking-widest">Short professional bio</label>
              <textarea 
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="What are your goals? (e.g., Building a dynamic newsletter aggregator to get 50 subscribers this month.)"
                className="w-full h-16 p-3 bg-slate-900 border border-white/5 rounded-xl text-xs focus:border-purple-500/50 outline-none text-slate-200 placeholder:text-slate-600 resize-none"
              />
            </div>

            <div className="flex justify-between items-center mt-8">
              <button 
                onClick={() => setStep("interests")}
                className="px-4 py-2.5 rounded-xl border border-white/5 hover:bg-white/5 text-xs font-semibold hover:text-white text-slate-400 transition-all flex items-center space-x-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>

              <button 
                onClick={handleFinishOnboarding}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-xs font-bold text-white transition-all shadow-lg flex items-center space-x-2 active:scale-95 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-purple-300" />
                <span>Finish Setup</span>
              </button>
            </div>
          </div>
        )}

        {/* Protection Banner */}
        <div className="mt-8 pt-4 border-t border-white/5 flex items-center justify-center space-x-2 text-[10px] text-slate-500">
          <Shield className="w-3 h-3 text-slate-600" />
          <span>Secured via local session vaults & telemetry keys</span>
        </div>

      </div>
    </div>
  );
}
